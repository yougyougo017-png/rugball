'use strict';

const { commands } = require('../src/commands/definitions');

const NAME = /^[-_\p{L}\p{N}]{1,32}$/u;
let failures = 0;

function check(condition, message) {
  if (condition) return;
  failures += 1;
  console.error(`  FAIL  ${message}`);
}

const seen = new Set();

for (const command of commands) {
  const json = command.toJSON();
  check(NAME.test(json.name), `command name "${json.name}" is invalid`);
  check(!seen.has(json.name), `duplicate command "${json.name}"`);
  seen.add(json.name);
  check(typeof json.description === 'string' && json.description.length > 0, `command "${json.name}" has no description`);
  check((json.description || '').length <= 100, `command "${json.name}" description is over 100 chars`);
  check(!json.options || json.options.length <= 25, `command "${json.name}" has too many options`);

  const optionNames = new Set();
  for (const option of json.options || []) {
    check(NAME.test(option.name), `${json.name}: option "${option.name}" is invalid`);
    check(!optionNames.has(option.name), `${json.name}: duplicate option "${option.name}"`);
    optionNames.add(option.name);
    check(typeof option.description === 'string' && option.description.length > 0, `${json.name}.${option.name} has no description`);

    for (const sub of option.options || []) {
      check(NAME.test(sub.name), `${json.name}.${option.name}: subcommand "${sub.name}" is invalid`);
      check(typeof sub.description === 'string' && sub.description.length > 0, `${json.name}.${option.name}.${sub.name} has no description`);
    }
  }
}

if (failures) {
  console.error(`\n${failures} command validation failure(s).`);
  process.exit(1);
}

console.log(`[VERIFY] ${commands.length} commands valid: ${[...seen].join(', ')}`);
