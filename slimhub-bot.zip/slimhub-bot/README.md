# SLIMHUB bot

Tickets, releases, announcements, and server scaffolding for the SLIMHUB Discord.

Written in Node with `discord.js` v14. Runs as one process, stores state in JSON files, needs no database.

## What it does

- **`/setup`** creates the whole server layout for you:
  - `SLIMHUB` category with `announcements`, `releases`, `support`, and a private `staff-logs`
  - `TICKETS` and `CLOSED TICKETS` categories, hidden from everyone except staff
  - posts the Open Ticket panel in `support`
- **Tickets** — a button opens a modal, the bot creates a private channel per ticket, staff can claim/close/add/remove/rename, and closing saves a transcript to the log channel.
- **`/release`** posts a branded release embed, optionally with a `.luau` attachment or a link.
- **`/announce`** posts a branded announcement, optionally pinging a role.
- **`/stats`** shows ticket counts, staff activity, gateway latency and uptime.

## Quick start

1. **Create the application**
   - <https://discord.com/developers/applications> → **New Application**
   - **Bot** tab → **Reset Token** → copy the token
   - **General Information** → copy the **Application ID**

2. **Install**
   ```powershell
   cd slimhub-bot
   npm install
   ```
   (Already installed in this folder.)

3. **Configure**
   ```powershell
   Copy-Item .env.example .env
   ```
   Fill in `DISCORD_TOKEN` and `CLIENT_ID`. Put your server ID in `GUILD_ID` so commands register instantly.

4. **Invite the bot**
   Replace `YOUR_CLIENT_ID` in this URL, or use **OAuth2 → URL Generator** in the portal:
   ```
   https://discord.com/oauth2/authorize?client_id=YOUR_CLIENT_ID&scope=bot%20applications.commands&permissions=268561424
   ```
   Those permissions are: View Channels, Send Messages, Manage Messages, Embed Links, Attach Files, Read Message History, Manage Channels, Manage Roles. No privileged intents required.

5. **Run**
   ```powershell
   npm start
   ```
   In the server, run **`/setup`**. It creates the channels, categories, log channel and posts the ticket panel in one shot.

## Commands

| Command | Who | What |
|---|---|---|
| `/ping` | everyone | Latency and uptime |
| `/help` | everyone | Command list |
| `/setup` | admin | Create categories, channels, logs, panel |
| `/ticketpanel [channel]` | staff | Repost the Open Ticket panel |
| `/ticket close [reason]` | owner/staff | Transcript, lock channel, move to closed |
| `/ticket claim [member]` | staff | Claim or assign |
| `/ticket add <member>` | staff | Give a member access |
| `/ticket remove <member>` | staff | Remove access |
| `/ticket rename <name>` | staff | Rename the channel |
| `/ticket list` | staff | List open tickets |
| `/release` | staff | Release embed + optional file/link |
| `/announce` | staff | Announcement embed |
| `/stats` | staff | Ticket and bot stats |

"Staff" means **Manage Server** or the configured staff role (`STAFF_ROLE_ID` in `.env`, or the role passed to `/setup staff_role:@Role`).

## Ticket flow

1. Member presses **Open Ticket** → modal asks subject + details.
2. Bot checks for an existing open ticket by that member, then creates `ticket-0001` in `TICKETS` with overwrites for the member, staff role and the bot.
3. Staff press **Claim** (locks the claim button, updates the topic and embed) or **Close**.
4. Closing posts a `.txt` transcript to `staff-logs`, denies the owner view, renames to `closed-0001`, moves it to `CLOSED TICKETS`, and deletes the channel after `TICKET_DELETE_SECONDS` (default 15, set `0` to keep it).

## Files

```
slimhub-bot/
├─ .env.example          config template
├─ package.json
├─ scripts/
│  └─ validate-commands.js   npm test — checks command names/descriptions/options
└─ src/
   ├─ config.js          env parsing
   ├─ store.js           JSON settings + tickets
   ├─ util.js            embeds, staff checks, formatting
   ├─ index.js           client + shutdown
   ├─ deploy-commands.js slash command registration
   ├─ commands/definitions.js
   └─ features/
      ├─ general.js      ping, help, stats
      ├─ setup.js        channel scaffolding
      ├─ tickets.js      panel, tickets, transcripts, cleanup
      ├─ content.js      release, announce
      └─ router.js       interaction dispatch
```

State lives in `data/settings.json` and `data/tickets.json`; transcripts in `transcripts/`. All three are gitignored.

## Checks

```powershell
npm test          # command schema validation
```

Current status: 8/8 commands valid, all JS files pass `node --check`.

## Hosting

Any always-on Node 18+ host works (VPS, Railway, Render, a spare PC). The bot only needs outbound HTTPS. Keep `data/` and `transcripts/` on persistent storage or you lose ticket history on redeploy.

For a quick local run, `npm start` and leave the terminal open. To keep it alive, use a process manager such as `pm2 start src/index.js --name slimhub`.

## Notes

- `AUTO_DEPLOY=true` + `GUILD_ID` re-registers commands on every boot. Set `GUILD_ID=` empty to use global commands instead (up to an hour to propagate).
- Never commit `.env` — it contains the bot token.
- The bot does not need the Message Content intent; it only reads messages when building a transcript via the REST API.
