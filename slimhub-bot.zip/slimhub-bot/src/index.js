'use strict';

const { Client, GatewayIntentBits, Events } = require('discord.js');
const config = require('./config');
const { handleInteraction } = require('./features/router');
const { cleanupClosedTickets } = require('./features/tickets');
const { deploy } = require('./deploy-commands');

if (!config.token) {
  console.error('[SLIMHUB] DISCORD_TOKEN is missing. Copy .env.example to .env and fill it in.');
  process.exit(1);
}

const client = new Client({
  intents: [GatewayIntentBits.Guilds],
});

client.once(Events.ClientReady, async (readyClient) => {
  console.log(`[SLIMHUB] online as ${readyClient.user.tag} in ${readyClient.guilds.cache.size} guild(s)`);

  if (config.autoDeploy && config.guildId) {
    try {
      await deploy(readyClient.user.id);
    } catch (error) {
      console.error('[DEPLOY]', error.message);
    }
  } else if (!config.guildId) {
    console.log('[SLIMHUB] GUILD_ID is empty; run "npm run deploy" to register global commands.');
  }

  try {
    await cleanupClosedTickets(readyClient);
  } catch (error) {
    console.warn('[TICKET] cleanup failed:', error.message);
  }
});

client.on(Events.InteractionCreate, handleInteraction);

client.on(Events.Error, (error) => {
  console.error('[DISCORD]', error);
});

client.on(Events.Warn, (message) => {
  console.warn('[DISCORD]', message);
});

let shuttingDown = false;
async function shutdown(signal) {
  if (shuttingDown) return;
  shuttingDown = true;
  console.log(`\n[SLIMHUB] ${signal}; shutting down.`);
  try {
    await client.destroy();
  } finally {
    process.exit(0);
  }
}

process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('unhandledRejection', (error) => {
  console.error('[UNHANDLED]', error);
});

client.login(config.token).catch((error) => {
  console.error('[SLIMHUB] login failed:', error.message);
  process.exit(1);
});
