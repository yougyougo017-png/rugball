'use strict';

const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const config = require('./config');

function brandEmbed(title, description, color) {
  return new EmbedBuilder()
    .setColor(color ?? config.embedColor)
    .setTitle(title || null)
    .setDescription(description || null)
    .setFooter({ text: 'SLIMHUB' })
    .setTimestamp();
}

function resolveStaffRoleId(settings) {
  return settings?.staffRoleId || config.staffRoleId || null;
}

function isStaff(interaction, settings) {
  if (interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) return true;
  const roleId = resolveStaffRoleId(settings);
  if (!roleId) return false;
  const roles = interaction.member?.roles;
  if (!roles) return false;
  if (roles.cache) return roles.cache.has(roleId);
  if (Array.isArray(roles)) return roles.includes(roleId);
  return false;
}

async function reply(interaction, payload, ephemeral = true) {
  const body = typeof payload === 'string' ? { content: payload } : { ...payload };
  if (ephemeral && body.ephemeral === undefined) body.ephemeral = true;
  if (interaction.deferred) {
    const { ephemeral: _ignored, ...editBody } = body;
    return interaction.editReply(editBody);
  }
  if (interaction.replied) return interaction.followUp(body);
  return interaction.reply(body);
}

async function sendLog(guild, settings, payload) {
  const channelId = settings?.logChannelId;
  if (!channelId) return false;
  try {
    const channel = await guild.channels.fetch(channelId);
    if (!channel?.isTextBased()) return false;
    await channel.send(payload);
    return true;
  } catch (error) {
    console.warn(`[LOG] could not post to ${channelId}: ${error.message}`);
    return false;
  }
}

function sanitizeChannelName(value, fallback = 'ticket') {
  const name = String(value || '')
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, '')
    .trim()
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '')
    .slice(0, 80);
  return name || fallback;
}

function ticketName(number) {
  return `ticket-${String(number).padStart(4, '0')}`;
}

function truncated(text, max = 1024) {
  const value = String(text ?? '');
  if (value.length <= max) return value;
  return `${value.slice(0, Math.max(0, max - 1))}…`;
}

function formatDuration(ms) {
  const seconds = Math.max(0, Math.floor(ms / 1000));
  const days = Math.floor(seconds / 86400);
  const hours = Math.floor((seconds % 86400) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = seconds % 60;
  const parts = [];
  if (days) parts.push(`${days}d`);
  if (hours) parts.push(`${hours}h`);
  if (minutes) parts.push(`${minutes}m`);
  if (!parts.length || secs) parts.push(`${secs}s`);
  return parts.join(' ');
}

function isSnowflake(value) {
  return /^\d{17,20}$/.test(String(value || ''));
}

function isValidHttpUrl(value) {
  try {
    const url = new URL(value);
    return url.protocol === 'http:' || url.protocol === 'https:';
  } catch {
    return false;
  }
}

module.exports = {
  brandEmbed,
  resolveStaffRoleId,
  isStaff,
  reply,
  sendLog,
  sanitizeChannelName,
  ticketName,
  truncated,
  formatDuration,
  isSnowflake,
  isValidHttpUrl,
};
