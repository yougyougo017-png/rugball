'use strict';

const path = require('node:path');
require('dotenv').config({ quiet: true });

function bool(value, fallback) {
  if (value === undefined || value === '') return fallback;
  return String(value).toLowerCase() === 'true';
}

function number(value, fallback, min, max) {
  const parsed = Number.parseInt(value, 10);
  if (!Number.isFinite(parsed)) return fallback;
  return Math.min(max, Math.max(min, parsed));
}

const root = path.join(__dirname, '..');

module.exports = {
  token: (process.env.DISCORD_TOKEN || '').trim(),
  clientId: (process.env.CLIENT_ID || '').trim(),
  guildId: (process.env.GUILD_ID || '').trim(),
  autoDeploy: bool(process.env.AUTO_DEPLOY, true),
  embedColor: number(process.env.EMBED_COLOR, 0xb2ff40, 0, 0xffffff),
  staffRoleId: (process.env.STAFF_ROLE_ID || '').trim(),
  ticketDeleteSeconds: number(process.env.TICKET_DELETE_SECONDS, 15, 0, 3600),
  dataDir: path.join(root, 'data'),
  transcriptDir: path.join(root, 'transcripts'),
};
