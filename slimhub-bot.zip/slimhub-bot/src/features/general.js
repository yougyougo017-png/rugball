'use strict';

const { ticketsForGuild } = require('../store');
const { brandEmbed, reply, formatDuration } = require('../util');

async function handlePing(interaction) {
  const roundtrip = Date.now() - interaction.createdTimestamp;
  return reply(interaction, {
    embeds: [
      brandEmbed('Pong')
        .addFields(
          { name: 'Gateway', value: `${Math.round(interaction.client.ws.ping)}ms`, inline: true },
          { name: 'Round trip', value: `${roundtrip}ms`, inline: true },
          { name: 'Uptime', value: formatDuration(interaction.client.uptime || 0), inline: true },
        ),
    ],
  });
}

async function handleHelp(interaction) {
  const embed = brandEmbed(
    'SLIMHUB commands',
    'Everything the bot can do. Staff commands need **Manage Server** or the configured staff role.',
  ).addFields(
    {
      name: 'Everyone',
      value: [
        '`/help` — this list',
        '`/ping` — bot latency and uptime',
        '**Open Ticket** — button on the support panel',
      ].join('\n'),
    },
    {
      name: 'Tickets',
      value: [
        '`/ticketpanel [channel]` — post the Open Ticket panel',
        '`/ticket close [reason]` — close the current ticket',
        '`/ticket claim [member]` — claim or assign a ticket',
        '`/ticket add <member>` — give a member access',
        '`/ticket remove <member>` — remove a member',
        '`/ticket rename <name>` — rename the channel',
        '`/ticket list` — list open tickets',
      ].join('\n'),
    },
    {
      name: 'Content',
      value: [
        '`/release` — post a script release with an optional file',
        '`/announce` — post an announcement embed',
        '`/stats` — ticket and bot statistics',
        '`/setup` — create channels, categories, logs and the panel',
      ].join('\n'),
    },
  );

  return reply(interaction, { embeds: [embed] }, false);
}

async function handleStats(interaction) {
  const guild = interaction.guild;
  if (!guild) return reply(interaction, 'This command only works in a server.');

  const tickets = ticketsForGuild(guild.id);
  const open = tickets.filter((ticket) => ticket.status === 'open').length;
  const claimed = tickets.filter((ticket) => ticket.status === 'claimed').length;
  const closed = tickets.filter((ticket) => ticket.status === 'closed').length;
  const yesterday = Date.now() - 24 * 60 * 60 * 1000;
  const recent = tickets.filter((ticket) => ticket.createdAt >= yesterday).length;
  const staff = new Set(tickets.map((ticket) => ticket.claimedBy).filter(Boolean)).size;

  return reply(interaction, {
    embeds: [
      brandEmbed('SLIMHUB statistics')
        .addFields(
          { name: 'Open', value: String(open), inline: true },
          { name: 'Claimed', value: String(claimed), inline: true },
          { name: 'Closed', value: String(closed), inline: true },
          { name: 'Total', value: String(tickets.length), inline: true },
          { name: 'Last 24h', value: String(recent), inline: true },
          { name: 'Staff who claimed', value: String(staff), inline: true },
          { name: 'Gateway', value: `${Math.round(interaction.client.ws.ping)}ms`, inline: true },
          { name: 'Uptime', value: formatDuration(interaction.client.uptime || 0), inline: true },
        ),
    ],
  });
}

module.exports = { handlePing, handleHelp, handleStats };
