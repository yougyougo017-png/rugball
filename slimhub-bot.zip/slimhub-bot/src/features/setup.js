'use strict';

const { ChannelType, PermissionFlagsBits } = require('discord.js');
const { getSettings, saveSettings } = require('../store');
const { brandEmbed, reply, resolveStaffRoleId } = require('../util');
const { postPanel } = require('./tickets');

function findChannel(guild, name, type) {
  return guild.channels.cache.find(
    (channel) => channel.type === type && channel.name.toLowerCase() === name.toLowerCase(),
  ) || null;
}

async function ensureCategory(guild, name, privateToStaff = false, staffRoleId = null) {
  let category = findChannel(guild, name, ChannelType.GuildCategory);
  if (!category) {
    category = await guild.channels.create({
      name,
      type: ChannelType.GuildCategory,
      reason: 'SLIMHUB setup',
    });
  }
  if (privateToStaff) await makePrivate(category, guild, staffRoleId);
  return category;
}

async function ensureText(guild, name, parent = null) {
  let channel = findChannel(guild, name, ChannelType.GuildText);
  if (!channel) {
    channel = await guild.channels.create({
      name,
      type: ChannelType.GuildText,
      parent: parent?.id ?? null,
      reason: 'SLIMHUB setup',
    });
  } else if (parent && channel.parentId !== parent.id) {
    await channel.setParent(parent.id, { lockPermissions: false }).catch(() => null);
  }
  return channel;
}

async function makePrivate(channel, guild, staffRoleId) {
  const everyone = guild.roles.everyone;
  await channel.permissionOverwrites.edit(everyone, { ViewChannel: false }).catch(() => null);
  if (staffRoleId) {
    await channel.permissionOverwrites.edit(staffRoleId, {
      ViewChannel: true,
      SendMessages: true,
      ReadMessageHistory: true,
      ManageMessages: true,
    }).catch(() => null);
  }
  if (guild.members.me) {
    await channel.permissionOverwrites.edit(guild.members.me, {
      ViewChannel: true,
      SendMessages: true,
      ReadMessageHistory: true,
      ManageMessages: true,
      AttachFiles: true,
      EmbedLinks: true,
    }).catch(() => null);
  }
}

async function handleSetup(interaction) {
  const guild = interaction.guild;
  if (!guild) return reply(interaction, 'This command only works in a server.');

  await interaction.deferReply({ ephemeral: true });

  const current = getSettings(guild.id);
  const createChannels = interaction.options.getBoolean('create_channels') ?? true;
  const warnings = [];
  const created = {};

  let staffRoleId = interaction.options.getRole('staff_role')?.id
    || resolveStaffRoleId(current)
    || guild.roles.cache.find((role) => role.name.toLowerCase() === 'staff')?.id
    || null;

  if (!staffRoleId) {
    warnings.push('No staff role found. Ticket channels are visible to admins and the ticket owner only. Re-run with `staff_role:@YourRole` to let staff see them.');
  }

  let supportChannel = current.supportChannelId
    ? guild.channels.cache.get(current.supportChannelId)
    : null;

  if (createChannels) {
    try {
      const hub = await ensureCategory(guild, 'SLIMHUB');
      const announcements = await ensureText(guild, 'announcements', hub);
      const releases = await ensureText(guild, 'releases', hub);
      supportChannel = await ensureText(guild, 'support', hub);
      const logs = await ensureText(guild, 'staff-logs', hub);
      await makePrivate(logs, guild, staffRoleId);

      created.announcementChannelId = announcements.id;
      created.releaseChannelId = releases.id;
      created.supportChannelId = supportChannel.id;
      created.logChannelId = logs.id;
    } catch (error) {
      warnings.push(`Could not create the SLIMHUB channels: ${error.message}`);
    }
  }

  const ticketOption = interaction.options.getChannel('ticket_category');
  const closedOption = interaction.options.getChannel('closed_category');
  let ticketCategory = ticketOption || (created.ticketCategoryId
    ? guild.channels.cache.get(created.ticketCategoryId)
    : current.ticketCategoryId ? guild.channels.cache.get(current.ticketCategoryId) : null);
  let closedCategory = closedOption || (current.closedCategoryId
    ? guild.channels.cache.get(current.closedCategoryId)
    : null);

  if (!ticketCategory) {
    try {
      ticketCategory = await ensureCategory(guild, 'TICKETS', true, staffRoleId);
    } catch (error) {
      warnings.push(`Could not create the TICKETS category: ${error.message}`);
    }
  } else {
    await makePrivate(ticketCategory, guild, staffRoleId);
  }

  if (!closedCategory) {
    try {
      closedCategory = await ensureCategory(guild, 'CLOSED TICKETS', true, staffRoleId);
    } catch (error) {
      warnings.push(`Could not create the CLOSED TICKETS category: ${error.message}`);
    }
  } else {
    await makePrivate(closedCategory, guild, staffRoleId);
  }

  const logOption = interaction.options.getChannel('log_channel');
  const releaseOption = interaction.options.getChannel('release_channel');
  const announceOption = interaction.options.getChannel('announcement_channel');

  if (logOption) {
    await makePrivate(logOption, guild, staffRoleId);
  }

  const patch = {
    staffRoleId,
    ticketCategoryId: ticketCategory?.id || current.ticketCategoryId || null,
    closedCategoryId: closedCategory?.id || current.closedCategoryId || null,
    logChannelId: logOption?.id || created.logChannelId || current.logChannelId || null,
    releaseChannelId: releaseOption?.id || created.releaseChannelId || current.releaseChannelId || null,
    announcementChannelId: announceOption?.id || created.announcementChannelId || current.announcementChannelId || null,
    supportChannelId: supportChannel?.id || current.supportChannelId || null,
    panelChannelId: supportChannel?.id || current.panelChannelId || null,
  };

  const next = saveSettings(guild.id, patch);

  let panelNote = 'No support channel configured. Run `/ticketpanel` in a channel to post the panel.';
  if (supportChannel?.isTextBased()) {
    try {
      const result = await postPanel(supportChannel, interaction.client);
      panelNote = result.existing
        ? `Ticket panel already present in ${supportChannel}.`
        : `Ticket panel posted in ${supportChannel}.`;
    } catch (error) {
      warnings.push(`Could not post the ticket panel: ${error.message}`);
      panelNote = 'Run `/ticketpanel` manually in the support channel.';
    }
  }

  const embed = brandEmbed('SLIMHUB setup complete')
    .addFields(
      {
        name: 'Staff role',
        value: next.staffRoleId ? `<@&${next.staffRoleId}>` : 'Not set',
        inline: true,
      },
      {
        name: 'Tickets',
        value: next.ticketCategoryId ? `<#${next.ticketCategoryId}>` : 'Not set',
        inline: true,
      },
      {
        name: 'Closed tickets',
        value: next.closedCategoryId ? `<#${next.closedCategoryId}>` : 'Not set',
        inline: true,
      },
      {
        name: 'Support',
        value: next.supportChannelId ? `<#${next.supportChannelId}>` : 'Not set',
        inline: true,
      },
      {
        name: 'Releases',
        value: next.releaseChannelId ? `<#${next.releaseChannelId}>` : 'Not set',
        inline: true,
      },
      {
        name: 'Announcements',
        value: next.announcementChannelId ? `<#${next.announcementChannelId}>` : 'Not set',
        inline: true,
      },
      {
        name: 'Logs',
        value: next.logChannelId ? `<#${next.logChannelId}>` : 'Not set',
        inline: true,
      },
      { name: 'Panel', value: panelNote, inline: false },
    );

  if (warnings.length) {
    embed.addFields({
      name: 'Warnings',
      value: warnings.map((warning) => `• ${warning}`).join('\n').slice(0, 1024),
    });
  }

  return interaction.editReply({ embeds: [embed] });
}

module.exports = { handleSetup };
