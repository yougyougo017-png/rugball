'use strict';

const { handlePing, handleHelp, handleStats } = require('./general');
const { handleSetup } = require('./setup');
const {
  handlePanel,
  handleCommand: handleTicketCommand,
  handleButton,
  handleModal,
} = require('./tickets');
const { handleRelease, handleAnnounce } = require('./content');

async function routeCommand(interaction) {
  switch (interaction.commandName) {
    case 'ping':
      return handlePing(interaction);
    case 'help':
      return handleHelp(interaction);
    case 'stats':
      return handleStats(interaction);
    case 'setup':
      return handleSetup(interaction);
    case 'ticketpanel':
      return handlePanel(interaction);
    case 'ticket':
      return handleTicketCommand(interaction);
    case 'release':
      return handleRelease(interaction);
    case 'announce':
      return handleAnnounce(interaction);
    default:
      return null;
  }
}

async function handleInteraction(interaction) {
  try {
    if (interaction.isChatInputCommand()) {
      await routeCommand(interaction);
      return;
    }
    if (interaction.isButton()) {
      await handleButton(interaction);
      return;
    }
    if (interaction.isModalSubmit()) {
      await handleModal(interaction);
    }
  } catch (error) {
    console.error('[INTERACTION]', error);
    try {
      if (!interaction.isRepliable()) return;
      const payload = { content: 'Something went wrong. The error was logged.', ephemeral: true };
      if (interaction.deferred) {
        await interaction.editReply(payload);
      } else if (interaction.replied) {
        await interaction.followUp(payload);
      } else {
        await interaction.reply(payload);
      }
    } catch {
      // interaction token expired; nothing to do
    }
  }
}

module.exports = { handleInteraction };
