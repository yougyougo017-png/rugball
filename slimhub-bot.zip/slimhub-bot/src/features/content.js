'use strict';

const { AttachmentBuilder } = require('discord.js');
const config = require('../config');
const { getSettings } = require('../store');
const { brandEmbed, reply, sendLog, truncated, isValidHttpUrl } = require('../util');

async function resolveChannel(interaction, settings, optionName, settingKey) {
  const option = interaction.options.getChannel(optionName);
  if (option) return option;
  const stored = settings[settingKey];
  if (stored) {
    const channel = await interaction.guild.channels.fetch(stored).catch(() => null);
    if (channel?.isTextBased()) return channel;
  }
  if (interaction.channel?.isTextBased()) return interaction.channel;
  return null;
}

async function handleRelease(interaction) {
  const guild = interaction.guild;
  if (!guild) return reply(interaction, 'This command only works in a server.');
  await interaction.deferReply({ ephemeral: true });

  const name = interaction.options.getString('name', true).trim();
  const game = interaction.options.getString('game', true).trim();
  const description = interaction.options.getString('description', true).trim();
  const version = interaction.options.getString('version')?.trim() || null;
  const link = interaction.options.getString('link')?.trim() || null;
  const pingRole = interaction.options.getRole('ping_role');
  const file = interaction.options.getAttachment('file');

  if (link && !isValidHttpUrl(link)) {
    return interaction.editReply('The link must start with http:// or https://');
  }

  const settings = getSettings(guild.id);
  const channel = await resolveChannel(interaction, settings, 'channel', 'releaseChannelId');
  if (!channel) {
    return interaction.editReply('No release channel found. Pass `channel:` or run `/setup` first.');
  }

  let attachment = null;
  if (file) {
    if (file.size > 8 * 1024 * 1024) {
      return interaction.editReply('That file is over 8 MB. Upload it somewhere and use the `link` option instead.');
    }
    try {
      const response = await fetch(file.url);
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const buffer = Buffer.from(await response.arrayBuffer());
      attachment = new AttachmentBuilder(buffer, { name: file.name });
    } catch (error) {
      console.warn('[RELEASE] file fetch failed:', error.message);
      return interaction.editReply('Could not download that attachment. Try a direct URL instead.');
    }
  }

  const embed = brandEmbed(`🚀 ${name}`, description)
    .addFields(
      { name: 'Game', value: truncated(game, 256), inline: true },
      { name: 'Version', value: version ? truncated(version, 100) : '—', inline: true },
      { name: 'Released by', value: `<@${interaction.user.id}>`, inline: true },
    );

  if (link) {
    embed.addFields({ name: 'Download', value: `[Open link](${link})`, inline: false });
    embed.setURL(link);
  }
  if (attachment) {
    embed.addFields({ name: 'File', value: truncated(file.name, 256), inline: false });
  }

  const payload = {
    content: pingRole ? `<@&${pingRole.id}>` : undefined,
    embeds: [embed],
    allowedMentions: { parse: [], roles: pingRole ? [pingRole.id] : [] },
  };
  if (attachment) payload.files = [attachment];

  let message;
  try {
    message = await channel.send(payload);
  } catch (error) {
    console.error('[RELEASE] send failed:', error);
    return interaction.editReply(`Could not post the release: ${error.message}`);
  }

  await sendLog(guild, settings, {
    embeds: [
      brandEmbed('Release posted')
        .addFields(
          { name: 'Name', value: truncated(name, 256), inline: true },
          { name: 'Game', value: truncated(game, 256), inline: true },
          { name: 'Channel', value: channel.toString(), inline: true },
          { name: 'Link', value: message.url },
        ),
    ],
  });

  return interaction.editReply(`Release posted: ${message.url}`);
}

async function handleAnnounce(interaction) {
  const guild = interaction.guild;
  if (!guild) return reply(interaction, 'This command only works in a server.');
  await interaction.deferReply({ ephemeral: true });

  const title = interaction.options.getString('title', true).trim();
  const text = interaction.options.getString('message', true).trim();
  const pingRole = interaction.options.getRole('ping_role');
  const settings = getSettings(guild.id);
  const channel = await resolveChannel(interaction, settings, 'channel', 'announcementChannelId');
  if (!channel) {
    return interaction.editReply('No announcement channel found. Pass `channel:` or run `/setup` first.');
  }

  const embed = brandEmbed(`📣 ${title}`, text)
    .setColor(config.embedColor)
    .setFooter({ text: `SLIMHUB • announced by ${interaction.user.username}` })
    .setTimestamp();

  let message;
  try {
    message = await channel.send({
      content: pingRole ? `<@&${pingRole.id}>` : undefined,
      embeds: [embed],
      allowedMentions: { parse: [], roles: pingRole ? [pingRole.id] : [] },
    });
  } catch (error) {
    console.error('[ANNOUNCE] send failed:', error);
    return interaction.editReply(`Could not post the announcement: ${error.message}`);
  }

  return interaction.editReply(`Announcement posted: ${message.url}`);
}

module.exports = { handleRelease, handleAnnounce };
