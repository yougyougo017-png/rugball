'use strict';

const { REST, Routes } = require('discord.js');
const config = require('./config');
const { commands } = require('./commands/definitions');

async function deploy(clientId = '') {
  if (!config.token) throw new Error('DISCORD_TOKEN is missing from .env');
  const applicationId = clientId || config.clientId;
  if (!applicationId) throw new Error('CLIENT_ID is missing from .env');

  const rest = new REST({ version: '10' }).setToken(config.token);
  const body = commands.map((command) => command.toJSON());

  if (config.guildId) {
    const result = await rest.put(
      Routes.applicationGuildCommands(applicationId, config.guildId),
      { body },
    );
    console.log(`[DEPLOY] registered ${result.length} guild commands in ${config.guildId}`);
    return result;
  }

  const result = await rest.put(
    Routes.applicationCommands(applicationId),
    { body },
  );
  console.log(`[DEPLOY] registered ${result.length} global commands (may take up to an hour to appear)`);
  return result;
}

if (require.main === module) {
  deploy().catch((error) => {
    console.error('[DEPLOY] failed:', error.message);
    process.exitCode = 1;
  });
}

module.exports = { deploy };
