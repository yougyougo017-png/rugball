'use strict';

const fs = require('node:fs');
const path = require('node:path');
const config = require('./config');

const DEFAULT_SETTINGS = {
  staffRoleId: null,
  ticketCategoryId: null,
  closedCategoryId: null,
  logChannelId: null,
  releaseChannelId: null,
  announcementChannelId: null,
  supportChannelId: null,
  panelChannelId: null,
  counter: 0,
};

class JsonStore {
  constructor(fileName) {
    this.file = path.join(config.dataDir, fileName);
    this.data = {};
    this.load();
  }

  load() {
    try {
      fs.mkdirSync(config.dataDir, { recursive: true });
      if (!fs.existsSync(this.file)) return;
      const raw = fs.readFileSync(this.file, 'utf8').trim();
      if (!raw) return;
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
        this.data = parsed;
      }
    } catch (error) {
      const backup = `${this.file}.corrupt-${Date.now()}`;
      try {
        if (fs.existsSync(this.file)) fs.renameSync(this.file, backup);
      } catch {
        // ignore backup failure
      }
      console.warn(`[STORE] ${this.file} was unreadable (${error.message}); starting empty. Backup: ${backup}`);
      this.data = {};
    }
  }

  get(key) {
    return this.data[key];
  }

  set(key, value) {
    this.data[key] = value;
    this.flush();
    return value;
  }

  delete(key) {
    if (!(key in this.data)) return false;
    delete this.data[key];
    this.flush();
    return true;
  }

  all() {
    return this.data;
  }

  flush() {
    fs.mkdirSync(config.dataDir, { recursive: true });
    const tmp = `${this.file}.tmp`;
    const payload = `${JSON.stringify(this.data, null, 2)}\n`;
    fs.writeFileSync(tmp, payload, 'utf8');
    try {
      fs.renameSync(tmp, this.file);
    } catch {
      // Windows can refuse a rename over an existing file in rare cases.
      fs.copyFileSync(tmp, this.file);
      fs.rmSync(tmp, { force: true });
    }
  }
}

const settingsStore = new JsonStore('settings.json');
const ticketStore = new JsonStore('tickets.json');

function getSettings(guildId) {
  return { ...DEFAULT_SETTINGS, ...(settingsStore.get(guildId) || {}) };
}

function saveSettings(guildId, patch) {
  const current = settingsStore.get(guildId) || {};
  const next = { ...current, ...patch };
  settingsStore.set(guildId, next);
  return { ...DEFAULT_SETTINGS, ...next };
}

function nextTicketNumber(guildId) {
  const settings = getSettings(guildId);
  const number = Math.max(0, Number(settings.counter) || 0) + 1;
  saveSettings(guildId, { counter: number });
  return number;
}

function getTicket(channelId) {
  return ticketStore.get(channelId) || null;
}

function saveTicket(ticket) {
  return ticketStore.set(ticket.channelId, ticket);
}

function allTickets() {
  return Object.values(ticketStore.all());
}

function ticketsForGuild(guildId) {
  return allTickets().filter((ticket) => ticket.guildId === guildId);
}

function findOpenTicket(guildId, userId) {
  return ticketsForGuild(guildId).find(
    (ticket) => ticket.userId === userId && ticket.status !== 'closed',
  ) || null;
}

module.exports = {
  DEFAULT_SETTINGS,
  getSettings,
  saveSettings,
  nextTicketNumber,
  getTicket,
  saveTicket,
  allTickets,
  ticketsForGuild,
  findOpenTicket,
};
