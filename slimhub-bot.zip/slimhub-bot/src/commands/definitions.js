'use strict';

const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ChannelType,
} = require('discord.js');

function base(name, description) {
  return new SlashCommandBuilder()
    .setName(name)
    .setDescription(description)
    .setDMPermission(false);
}

const commands = [
  base('ping', 'Check that the bot is alive.'),
  base('help', 'Show every SLIMHUB command.'),

  base('setup', 'Create the SLIMHUB channels, ticket categories and support panel.')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addBooleanOption((option) => option
      .setName('create_channels')
      .setDescription('Create any missing SLIMHUB categories and channels (default: true)'))
    .addRoleOption((option) => option
      .setName('staff_role')
      .setDescription('Role that can see and manage tickets'))
    .addChannelOption((option) => option
      .setName('log_channel')
      .setDescription('Private channel for ticket and release logs')
      .addChannelTypes(ChannelType.GuildText))
    .addChannelOption((option) => option
      .setName('ticket_category')
      .setDescription('Category where open tickets are created')
      .addChannelTypes(ChannelType.GuildCategory))
    .addChannelOption((option) => option
      .setName('closed_category')
      .setDescription('Category where closed tickets are moved')
      .addChannelTypes(ChannelType.GuildCategory))
    .addChannelOption((option) => option
      .setName('release_channel')
      .setDescription('Channel for /release posts')
      .addChannelTypes(ChannelType.GuildText))
    .addChannelOption((option) => option
      .setName('announcement_channel')
      .setDescription('Channel for /announce posts')
      .addChannelTypes(ChannelType.GuildText)),

  base('ticketpanel', 'Post the Open Ticket panel in a channel.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addChannelOption((option) => option
      .setName('channel')
      .setDescription('Where to post the panel (default: configured support channel)')
      .addChannelTypes(ChannelType.GuildText)),

  base('ticket', 'Manage the ticket in this channel.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand((sub) => sub
      .setName('close')
      .setDescription('Close this ticket and save a transcript')
      .addStringOption((option) => option
        .setName('reason')
        .setDescription('Why the ticket was closed')
        .setMaxLength(400)))
    .addSubcommand((sub) => sub
      .setName('add')
      .setDescription('Add a member to this ticket')
      .addUserOption((option) => option
        .setName('member')
        .setDescription('Member to add')
        .setRequired(true)))
    .addSubcommand((sub) => sub
      .setName('remove')
      .setDescription('Remove a member from this ticket')
      .addUserOption((option) => option
        .setName('member')
        .setDescription('Member to remove')
        .setRequired(true)))
    .addSubcommand((sub) => sub
      .setName('claim')
      .setDescription('Claim this ticket as staff')
      .addUserOption((option) => option
        .setName('member')
        .setDescription('Optional: assign the ticket to a different staff member')))
    .addSubcommand((sub) => sub
      .setName('rename')
      .setDescription('Rename this ticket channel')
      .addStringOption((option) => option
        .setName('name')
        .setDescription('New channel name')
        .setMaxLength(90)
        .setRequired(true)))
    .addSubcommand((sub) => sub
      .setName('list')
      .setDescription('List open tickets')),

  base('release', 'Post a script release with an optional file.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addStringOption((option) => option
      .setName('name')
      .setDescription('Script / hub name')
      .setMaxLength(100)
      .setRequired(true))
    .addStringOption((option) => option
      .setName('game')
      .setDescription('Game or place this is for')
      .setMaxLength(100)
      .setRequired(true))
    .addStringOption((option) => option
      .setName('description')
      .setDescription('What it does')
      .setMaxLength(1000)
      .setRequired(true))
    .addStringOption((option) => option
      .setName('version')
      .setDescription('Version label, e.g. v2.1')
      .setMaxLength(50))
    .addStringOption((option) => option
      .setName('link')
      .setDescription('Raw URL or download link')
      .setMaxLength(500))
    .addAttachmentOption((option) => option
      .setName('file')
      .setDescription('Optional .luau file to upload with the post'))
    .addChannelOption((option) => option
      .setName('channel')
      .setDescription('Where to post (default: configured release channel)')
      .addChannelTypes(ChannelType.GuildText))
    .addRoleOption((option) => option
      .setName('ping_role')
      .setDescription('Optional role to ping')),

  base('announce', 'Post an announcement embed.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addStringOption((option) => option
      .setName('title')
      .setDescription('Announcement title')
      .setMaxLength(100)
      .setRequired(true))
    .addStringOption((option) => option
      .setName('message')
      .setDescription('Announcement body')
      .setMaxLength(2000)
      .setRequired(true))
    .addChannelOption((option) => option
      .setName('channel')
      .setDescription('Where to post (default: configured announcements channel)')
      .addChannelTypes(ChannelType.GuildText))
    .addRoleOption((option) => option
      .setName('ping_role')
      .setDescription('Optional role to ping')),

  base('stats', 'Ticket and bot statistics.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
];

const commandsByName = new Map(commands.map((command) => [command.name, command]));

module.exports = { commands, commandsByName };
